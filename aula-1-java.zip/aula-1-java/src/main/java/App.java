public class App {
    public static void main(String[] args) {
        // Não se instacia classe abstrata

        Engenheiro joao = new Engenheiro("26535525", "João Vitor", 15.000);
        System.out.println(joao);

        Vendedor serginho = new Vendedor("25655555", "Sérginho", 10.000,20.0);

        Horista italo = new Horista("56555656", "Ínstalones", 10, 2.0);

        System.out.println(serginho);
        System.out.println("***************************");


        Empresa b2b = new Empresa();

        b2b.adicionaFunc(serginho);
        b2b.adicionaFunc(italo);

        System.out.println("Exibindo horista");
        b2b.exibeHoristas();

        System.out.println("Exibindo total Salarios:");
        b2b.exibeTotalSalario();
    }
}
