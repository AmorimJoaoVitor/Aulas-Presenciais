import java.util.ArrayList;
import java.util.List;

public class Empresa {

     List<Funcionario> funcionarioList;

    public Empresa() {
        this.funcionarioList = new ArrayList<Funcionario>();
    }

    public void adicionaFunc(Funcionario f){
     funcionarioList.add(f);
 }

 public void exibeTodos(){
     for (Funcionario f : funcionarioList ) {
         System.out.println(f);
     }
 }

 public void exibeTotalSalario(){
     Double totalSalario = 0.0;
     for (Funcionario f : funcionarioList){
          totalSalario += f.calcSalario();
     }
     System.out.println(totalSalario);
 }

 public void exibeHoristas(){
     for (Funcionario f : funcionarioList){
         if (f instanceof Horista){
             System.out.println(f);
         }
     }
 }
}
